#!/bin/bash
# bcsample - An example of calculations with bc
if [ $# != 1 ]
  then
  echo "A number argument is required"
  exit
fi

bc <<END-OF-INPUT
  scale=6
  /* first we define the function */
  define myfunc(x){
  return(sqrt(x) + 10);
  }

  /* then use the function to do the calculation*/
 x=$1
 "Processing";x;" result is ";myfunc(x)
 quit
END-OF-INPUT

echo "(to 6 decimal places)"